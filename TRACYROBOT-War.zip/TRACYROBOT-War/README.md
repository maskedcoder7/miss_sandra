












<p align="center">
  <img src="https://media.giphy.com/media/Qv9p77hBf48DutDzvr/giphy.gif">
</p>

# TracyRobot
Me On Telegram [✨TRACY✨](https://t.me/TracyRoBot)
This is just a demo bot.. Don't try to add to your group.. Create your own bot 
## How To Host
The easiest way to deploy this Bot
<p align="center"><a href="https://heroku.com/deploy?template=https://github.com/war-legend/TracyRoBot"> <img src="https://img.shields.io/badge/Deploy%20To%20Heroku-black?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>
 
## CREDITS
▪️[itsmelegend](https://github.com/war-legend)

▪️ [PaulSonOfLars](https://github.com/PaulSonOfLars/tgbot)
▪️ [Saitama](https://github.com/AnimeKaizoku)
▪️ [Loli-Killer](https://github.com/Loli-Killer)
▪️ [RealAkito](https://github.com/RealAkito)
▪️ [MrYacha](https://github.com/MrYacha)
▪️ [Shreyansh](https://github.com/okay-retard)
▪️ [Ayush](https://github.com/MissJuliaRobot/MissJuliaRobot)
▪️ [Inuka Asith](https://github.com/inukaasith)
▪️ [Legendx](https://github.com/LEGENDXOP)
▪️ [Amarnath c](https://github.com/Amarnathcdj)
▪️ [Thehamkercat](https://github.com/thehamkercat)
▪️ [DragSama](https://github.com/DragSama)
▪️ [Shrimadhav](https://github.com/SpEcHiDe)
▪️ [Ayra Hikari](https://github.com/AyraHikari)
